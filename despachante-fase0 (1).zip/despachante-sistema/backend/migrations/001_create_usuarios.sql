-- Migration 001 — Fase 0
-- Cria a tabela usuarios (autenticação).
-- Campos conforme references/03_DATABASE.md (skill despachante-sistema).

CREATE TABLE IF NOT EXISTS usuarios (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  senha_hash VARCHAR(255) NOT NULL,
  perfil VARCHAR(20) CHECK (perfil IN ('admin','operador','consulta')) DEFAULT 'operador',
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT NOW(),
  atualizado_em TIMESTAMP,
  deletado_em TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios (email) WHERE deletado_em IS NULL;
