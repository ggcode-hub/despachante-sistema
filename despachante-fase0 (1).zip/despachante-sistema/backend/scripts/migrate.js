// Script simples de migração para a Fase 0.
// Uso: npm run migrate
//
// O que faz:
// 1. Executa todos os arquivos .sql da pasta migrations/, em ordem alfabética.
// 2. Se não existir nenhum usuário, cria o usuário admin inicial (definido no .env
//    ou usando um padrão — que deve ser trocado no primeiro acesso).

const fs = require('fs');
const path = require('path');
const pool = require('../src/config/database');
const authService = require('../src/modules/auth/auth.service');

async function rodarMigracoes() {
  const pasta = path.join(__dirname, '..', 'migrations');
  const arquivos = fs.readdirSync(pasta).filter((f) => f.endsWith('.sql')).sort();

  for (const arquivo of arquivos) {
    console.log(`Aplicando migração: ${arquivo}`);
    const sql = fs.readFileSync(path.join(pasta, arquivo), 'utf8');
    await pool.query(sql);
  }
  console.log('Migrações aplicadas com sucesso.');
}

async function criarAdminInicialSeNecessario() {
  const nome = process.env.ADMIN_NOME || 'Administrador';
  const email = process.env.ADMIN_EMAIL || 'admin@despachante.local';
  const senha = process.env.ADMIN_SENHA || 'trocar123';

  const { rows } = await pool.query('SELECT COUNT(*)::int AS total FROM usuarios');
  if (rows[0].total > 0) {
    console.log('Já existem usuários cadastrados — nenhum admin inicial foi criado.');
    return;
  }

  await authService.criarUsuarioInicial({ nome, email, senha });
  console.log('----------------------------------------------------');
  console.log('Usuário administrador inicial criado:');
  console.log(`  E-mail: ${email}`);
  console.log(`  Senha:  ${senha}`);
  console.log('IMPORTANTE: troque essa senha assim que fizer o primeiro login.');
  console.log('----------------------------------------------------');
}

async function main() {
  try {
    await rodarMigracoes();
    await criarAdminInicialSeNecessario();
  } catch (err) {
    console.error('Erro ao rodar migrações:', err);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
}

main();
