const service = require('./auth.service');

// Controller: recebe dados, chama o service, devolve resposta. Nunca acessa o banco diretamente.

async function login(req, res, next) {
  try {
    const { email, senha } = req.body;
    const resultado = await service.login(email, senha);
    return res.json(resultado);
  } catch (err) {
    return next(err);
  }
}

async function me(req, res, next) {
  try {
    const usuario = await service.obterUsuarioAutenticado(req.usuario.id);
    return res.json({ usuario });
  } catch (err) {
    return next(err);
  }
}

module.exports = { login, me };
