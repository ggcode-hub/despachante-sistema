const pool = require('../../config/database');

// Repository: único lugar que executa SQL para o módulo de autenticação.
// Sempre queries parametrizadas ($1, $2...) — nunca concatenação de string.

async function buscarPorEmail(email) {
  const { rows } = await pool.query(
    `SELECT id, nome, email, senha_hash, perfil, ativo
     FROM usuarios
     WHERE email = $1 AND deletado_em IS NULL`,
    [email]
  );
  return rows[0] || null;
}

async function buscarPorId(id) {
  const { rows } = await pool.query(
    `SELECT id, nome, email, perfil, ativo
     FROM usuarios
     WHERE id = $1 AND deletado_em IS NULL`,
    [id]
  );
  return rows[0] || null;
}

async function contarUsuarios() {
  const { rows } = await pool.query(
    `SELECT COUNT(*)::int AS total FROM usuarios WHERE deletado_em IS NULL`
  );
  return rows[0].total;
}

async function criarUsuario({ nome, email, senhaHash, perfil }) {
  const { rows } = await pool.query(
    `INSERT INTO usuarios (nome, email, senha_hash, perfil)
     VALUES ($1, $2, $3, $4)
     RETURNING id, nome, email, perfil, ativo, criado_em`,
    [nome, email, senhaHash, perfil]
  );
  return rows[0];
}

module.exports = {
  buscarPorEmail,
  buscarPorId,
  contarUsuarios,
  criarUsuario,
};
