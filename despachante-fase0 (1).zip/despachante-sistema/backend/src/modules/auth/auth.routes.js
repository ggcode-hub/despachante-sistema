const express = require('express');
const controller = require('./auth.controller');
const authMiddleware = require('../../middlewares/authMiddleware');
const { validate } = require('../../middlewares/validationMiddleware');

const router = express.Router();

const validarLogin = (body) => {
  if (!body.email) return 'O campo "email" é obrigatório.';
  if (!body.senha) return 'O campo "senha" é obrigatório.';
  return null;
};

// POST /api/auth/login
router.post('/login', validate(validarLogin), controller.login);

// GET /api/auth/me — rota protegida, exige token válido
router.get('/me', authMiddleware, controller.me);

module.exports = router;
