const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const env = require('../../config/env');
const AppError = require('../../utils/AppError');
const repository = require('./auth.repository');

const SALT_ROUNDS = 10;

// Service: aqui ficam as regras. Nunca SQL aqui, nunca no controller.

async function login(email, senha) {
  if (!email || !senha) {
    throw new AppError('E-mail e senha são obrigatórios.', 400);
  }

  const usuario = await repository.buscarPorEmail(email.toLowerCase().trim());

  // Mensagem genérica de propósito: não revelar se o e-mail existe ou não,
  // nem se foi a senha ou o e-mail que estava errado (evita enumeração de usuários).
  if (!usuario || !usuario.ativo) {
    throw new AppError('E-mail ou senha inválidos.', 401);
  }

  const senhaCorreta = await bcrypt.compare(senha, usuario.senha_hash);
  if (!senhaCorreta) {
    throw new AppError('E-mail ou senha inválidos.', 401);
  }

  const payload = {
    id: usuario.id,
    nome: usuario.nome,
    email: usuario.email,
    perfil: usuario.perfil,
  };

  const token = jwt.sign(payload, env.jwtSecret, { expiresIn: env.jwtExpiresIn });

  return { token, usuario: payload };
}

async function obterUsuarioAutenticado(id) {
  const usuario = await repository.buscarPorId(id);
  if (!usuario) {
    throw new AppError('Usuário não encontrado.', 404);
  }
  return usuario;
}

// Usado pelo script de seed (scripts/migrate.js) para criar o primeiro usuário admin.
// Regra da skill: perfil existe desde a Fase 0, mas sem bloqueio de permissão ainda.
// O primeiro usuário do sistema é sempre 'admin'; os demais entram como 'operador' por padrão.
async function criarUsuarioInicial({ nome, email, senha }) {
  const totalUsuarios = await repository.contarUsuarios();
  const perfil = totalUsuarios === 0 ? 'admin' : 'operador';

  const senhaHash = await bcrypt.hash(senha, SALT_ROUNDS);
  return repository.criarUsuario({ nome, email: email.toLowerCase().trim(), senhaHash, perfil });
}

module.exports = {
  login,
  obterUsuarioAutenticado,
  criarUsuarioInicial,
};
