const express = require('express');
const cors = require('cors');
const env = require('./config/env');
const errorHandler = require('./middlewares/errorHandler');
const authRoutes = require('./modules/auth/auth.routes');

const app = express();

app.use(cors({ origin: env.corsOrigin }));
app.use(express.json());

// Rota de verificação simples — útil para checar se o deploy subiu corretamente.
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', servico: 'despachante-backend', fase: 0 });
});

app.use('/api/auth', authRoutes);

// Rota não encontrada
app.use('/api', (req, res) => {
  res.status(404).json({ erro: 'Rota não encontrada.' });
});

// Middleware de erro deve ser o último a ser registrado
app.use(errorHandler);

app.listen(env.porta, () => {
  console.log(`Servidor rodando na porta ${env.porta}`);
});
