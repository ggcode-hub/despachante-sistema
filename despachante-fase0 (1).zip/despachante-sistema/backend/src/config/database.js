const { Pool } = require('pg');
const env = require('./env');

// Pool de conexões com o PostgreSQL.
// Todo módulo (repository) deve usar este pool — nunca criar uma conexão própria.
const pool = new Pool({
  connectionString: env.databaseUrl,
  // Railway/Render exigem SSL em produção; em desenvolvimento local (sem SSL) isso é ignorado.
  ssl: env.databaseUrl.includes('localhost') ? false : { rejectUnauthorized: false },
});

pool.on('error', (err) => {
  console.error('Erro inesperado na conexão com o banco de dados:', err.message);
});

module.exports = pool;
