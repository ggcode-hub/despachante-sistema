require('dotenv').config();

// Centraliza a leitura de variáveis de ambiente.
// Nenhum outro arquivo do projeto deve chamar process.env diretamente —
// sempre importar daqui, para termos um único ponto de verdade.

function obrigatoria(nome) {
  const valor = process.env[nome];
  if (!valor) {
    throw new Error(`Variável de ambiente obrigatória ausente: ${nome}`);
  }
  return valor;
}

module.exports = {
  porta: process.env.PORT || 3000,
  databaseUrl: obrigatoria('DATABASE_URL'),
  jwtSecret: obrigatoria('JWT_SECRET'),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  corsOrigin: process.env.CORS_ORIGIN || '*',
};
