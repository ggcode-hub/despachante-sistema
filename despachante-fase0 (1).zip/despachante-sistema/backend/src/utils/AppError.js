// Erro previsível de aplicação (regra de negócio, validação, autenticação).
// Usar isso em vez de "throw new Error(...)" solto, para o errorHandler
// saber diferenciar "erro esperado" (mostrar mensagem) de "erro interno" (esconder detalhe).
class AppError extends Error {
  constructor(mensagem, statusCode = 400) {
    super(mensagem);
    this.statusCode = statusCode;
    this.isAppError = true;
  }
}

module.exports = AppError;
