// Middleware de erro do Express (precisa ter 4 parâmetros para o Express reconhecer como tal).
// Regra da skill: nunca expor detalhe interno (stack trace, erro de SQL, etc.) para o usuário final.
function errorHandler(err, req, res, next) {
  if (err.isAppError) {
    return res.status(err.statusCode).json({ erro: err.message });
  }

  // Erro não previsto: logamos o detalhe real no servidor, mas escondemos do cliente.
  console.error('Erro interno não tratado:', err);
  return res.status(500).json({ erro: 'Não foi possível concluir a operação.' });
}

module.exports = errorHandler;
