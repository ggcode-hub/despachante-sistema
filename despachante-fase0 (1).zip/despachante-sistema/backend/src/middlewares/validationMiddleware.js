// Middleware de validação simples e genérico para a Fase 0.
// Recebe uma função de validação (validatorFn) que retorna uma string de erro
// ou null/undefined se estiver tudo certo.
// Módulos futuros podem trocar por uma lib de validação (ex: zod, joi) sem
// mudar o contrato: sempre `validate(fn)` retornando um middleware do Express.
function validate(validatorFn) {
  return (req, res, next) => {
    const erro = validatorFn(req.body || {});
    if (erro) {
      return res.status(400).json({ erro });
    }
    next();
  };
}

module.exports = { validate };
