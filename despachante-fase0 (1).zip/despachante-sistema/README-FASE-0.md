# Fase 0 — Fundação Técnica

Login funcionando, banco PostgreSQL estruturado, e API pronta pra crescer nas próximas fases.

## O que esta fase entrega

- Backend Node.js + Express, organizado em camadas (Route → Controller → Service → Repository)
- Autenticação com JWT + senha criptografada (bcryptjs)
- Tabela `usuarios` no PostgreSQL (com soft delete e campo `perfil` já preparado)
- Tela de login funcional (frontend simples, em HTML/CSS/JS puro)
- Rota `/api/health` pra verificar se o servidor está no ar
- Rota protegida `/api/auth/me` pra confirmar que o token funciona

**O que ainda NÃO existe nesta fase** (vem nas próximas): Clientes, Veículos, Produtos, Pedidos, Caixa, Consultas, Relatórios. É esperado que o sistema pareça "vazio" além do login — essa é a fundação, não o produto final.

---

## 1. Rodando localmente (antes de fazer deploy)

### Pré-requisitos
- Node.js instalado
- PostgreSQL instalado (ou um serviço PostgreSQL na nuvem, ex: um banco criado no Railway)

### Passos

```bash
cd backend
npm install
```

Copie o arquivo de exemplo de variáveis de ambiente e preencha com os dados do seu banco:

```bash
cp .env.example .env
```

Edite o `.env` com:
- `DATABASE_URL` — string de conexão do seu PostgreSQL
- `JWT_SECRET` — troque pelo valor sugerido no próprio arquivo (gere uma chave aleatória forte)
- `ADMIN_EMAIL` / `ADMIN_SENHA` — credenciais do primeiro usuário administrador (opcional; se não definir, usa um padrão que também funciona, mas troque a senha depois)

Rode a migração (cria a tabela `usuarios` e o usuário admin inicial):

```bash
npm run migrate
```

Você vai ver no terminal o e-mail e a senha do admin criado — **anote e troque depois**.

Suba o servidor:

```bash
npm run dev
```

O backend vai responder em `http://localhost:3000`.

### Testando a tela de login

Abra o arquivo `frontend/index.html` diretamente no navegador (ou sirva com uma extensão tipo "Live Server" do VS Code). Se o backend estiver rodando em outra porta/domínio, ajuste a constante `API_URL` no arquivo `frontend/js/auth.js`.

Teste com o e-mail/senha do admin criado na migração.

---

## 2. Fazendo o deploy (Railway — recomendado)

1. Crie uma conta em [railway.app](https://railway.app)
2. Crie um novo projeto e escolha **"Deploy from GitHub repo"** (você precisa ter subido esta pasta pro seu GitHub antes — veja seção 3)
3. Dentro do projeto, clique em **"+ New"** → **Database** → **PostgreSQL**. O Railway cria o banco e já disponibiliza a variável `DATABASE_URL` automaticamente
4. No serviço do backend (o que veio do seu repositório GitHub), vá em **Variables** e adicione:
   - `DATABASE_URL` → copie o valor gerado pelo serviço PostgreSQL (Railway costuma referenciar automaticamente, veja `${{Postgres.DATABASE_URL}}`)
   - `JWT_SECRET` → uma chave forte e aleatória
   - `JWT_EXPIRES_IN` → `8h`
   - `CORS_ORIGIN` → o domínio de onde o frontend vai ser servido (ajuste depois se mudar)
   - `ADMIN_EMAIL` / `ADMIN_SENHA` → credenciais do admin inicial
5. Em **Settings**, defina o **Root Directory** como `backend` (já que o projeto tem `backend/` e `frontend/` na mesma pasta)
6. Em **Settings → Deploy**, configure:
   - **Build command:** `npm install`
   - **Start command:** `npm run migrate && npm start`
   *(rodar a migração antes de iniciar garante que a tabela existe no primeiro deploy)*
7. Clique em **Deploy**. Ao final, o Railway te dá um link público (ex: `https://despachante-production.up.railway.app`)
8. Teste: acesse `https://SEU-LINK/api/health` — deve responder `{"status":"ok",...}`

### Onde fica o frontend?

Nesta fase, o mais simples é você abrir o `frontend/index.html` localmente (ajustando `API_URL` pro link do Railway) ou publicar essa pasta em um serviço simples de arquivo estático (o próprio Railway também serve isso, ou pode usar Vercel/Netlify gratuitamente). A partir da Fase 1, à medida que o frontend crescer, definimos junto o melhor lugar pra hospedá-lo definitivamente.

---

## 3. Subindo o código pro GitHub (necessário antes do passo 2)

```bash
git init
git add .
git commit -m "Fase 0 - Fundacao tecnica"
git branch -M main
git remote add origin <link-do-seu-repositorio-no-github>
git push -u origin main
```

O `.gitignore` já está configurado para nunca subir `node_modules/` nem o `.env` com suas senhas reais.

---

## 4. Checklist antes de considerar a Fase 0 aprovada

- [ ] Rodei localmente e consegui logar com o admin criado
- [ ] Tentei senha errada e recebi erro (`E-mail ou senha inválidos.`)
- [ ] Acessei `/api/auth/me` sem token e recebi `Não autorizado`
- [ ] Acessei `/api/auth/me` com token e recebi meus dados
- [ ] Fiz o deploy no Railway e o link público respondeu em `/api/health`
- [ ] Troquei a senha padrão do admin (ou já criei com uma senha forte no `.env`)

Quando isso tudo estiver certo, me avise para avançarmos para a **Fase 1 — Cadastros principais**.
