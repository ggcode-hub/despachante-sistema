// Ajuste esta URL quando fizer o deploy (ex: https://despachante-xxx.up.railway.app/api)
const API_URL = 'http://localhost:3000/api';

const form = document.getElementById('form-login');
const mensagemErro = document.getElementById('mensagem-erro');
const areaLogado = document.getElementById('area-logado');
const usuarioInfo = document.getElementById('usuario-info');
const btnSair = document.getElementById('btn-sair');

function salvarSessao(token, usuario) {
  // Fase 0: guardamos em memória via variável de módulo (sessionStorage também serviria).
  sessionStorage.setItem('token', token);
  sessionStorage.setItem('usuario', JSON.stringify(usuario));
}

function limparSessao() {
  sessionStorage.removeItem('token');
  sessionStorage.removeItem('usuario');
}

function mostrarLogado(usuario) {
  form.classList.add('oculto');
  areaLogado.classList.remove('oculto');
  usuarioInfo.textContent = `${usuario.nome} — perfil: ${usuario.perfil}`;
}

async function tentarLogin(email, senha) {
  const resposta = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, senha }),
  });

  const dados = await resposta.json();

  if (!resposta.ok) {
    throw new Error(dados.erro || 'Não foi possível entrar.');
  }

  return dados;
}

form.addEventListener('submit', async (evento) => {
  evento.preventDefault();
  mensagemErro.textContent = '';

  const email = document.getElementById('email').value.trim();
  const senha = document.getElementById('senha').value;

  try {
    const { token, usuario } = await tentarLogin(email, senha);
    salvarSessao(token, usuario);
    mostrarLogado(usuario);
  } catch (err) {
    mensagemErro.textContent = err.message;
  }
});

btnSair.addEventListener('click', () => {
  limparSessao();
  areaLogado.classList.add('oculto');
  form.classList.remove('oculto');
  form.reset();
});

// Se já existir uma sessão salva (ex: usuário deu F5 na página), mantém logado.
(function restaurarSessao() {
  const usuarioSalvo = sessionStorage.getItem('usuario');
  if (usuarioSalvo) {
    mostrarLogado(JSON.parse(usuarioSalvo));
  }
})();
